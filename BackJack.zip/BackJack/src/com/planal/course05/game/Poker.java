package com.planal.course05.game;

import com.planal.course05.main.Main;
import com.planal.course05.tools.Tools;

import android.graphics.Bitmap;

public class Poker
{
	public static final int NI_RECT_MAX = 364;
	public static final int NI_START_X = 225;
	public final int NI_WIDTH,NI_HEIGHT;
	
	private Bitmap[][] arrBmpPoker;
	private StringBuffer sbufPoker;
	
	public Poker()
	{
		arrBmpPoker = new Bitmap[4][13];
		char[] arrPockerType  = {'d','c','h','s'};
		for (int i = 0; i < arrBmpPoker.length; i++)
		{
			for (int j = 0; j < arrBmpPoker[i].length; j++)
			{
				arrBmpPoker[i][j] = Tools.readImage(Main.getAssetManager(), "res/poker/"+arrPockerType[i]+(j+1)+".png");
			}
		}

		NI_WIDTH = arrBmpPoker[0][0].getWidth(); 
		NI_HEIGHT = arrBmpPoker[0][0].getHeight();
		
		sbufPoker = new StringBuffer();
		
		shuffle();
	}
	
	public void shuffle()
	{
		if(sbufPoker.length()>0)
			sbufPoker.delete(0,sbufPoker.length());
		
		for (int i = 0; i < arrBmpPoker.length; i++)
		{
			for (int j = 0; j < arrBmpPoker[i].length; j++)
			{
				sbufPoker.append(i+","+j+";");
			}
		}
		Tools.logInfo(sbufPoker.toString());
	}
	
	public String dealing()
	{
		//���ַ����ָ���ַ�������
		String[] arrStrPoker = sbufPoker.toString().split(";");
		//�����ȡһ����
		String strPoker = arrStrPoker[Tools.getRandom(0, arrStrPoker.length)];
		//������ʼλ��
		int niStartIdx = sbufPoker.indexOf(strPoker+";");
		//��������λ�ã���1��Ϊ�˰�;ɾ����
		int niOverIdx = sbufPoker.indexOf(";",niStartIdx)+1;
		//ɾ��������
		sbufPoker.delete(niStartIdx,niOverIdx);
		//���س�ȡ����
		return strPoker+";";
	}
	
	public Bitmap getPoker(int niType,int niDot)
	{
		return arrBmpPoker[niType][niDot];
	}
}
