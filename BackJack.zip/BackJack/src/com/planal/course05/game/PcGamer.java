package com.planal.course05.game;

import com.planal.course05.tools.Tools;

public class PcGamer extends Player
{
	public static final int NI_POKER_Y = 24;
	private boolean isStand;
	
	public PcGamer(Poker poker)
	{
		super(poker, NI_POKER_Y);
	}

	@Override
	public void drawTiles(String strPoker)
	{
		
		if(isStand)
			return;
		if(getPokerSum() >= 5)
		{
			isStand = true;
			return;
		}
		if(getPokerSum() < 2)
			sbufPokerAll.append(strPoker);
		else if(getDot() < 17)
			sbufPokerAll.append(strPoker);
		else if(getDot() == 21)
			isStand = true;
		else if(isSoftHand() && Tools.getRandom(0, 3) == 0)
			sbufPokerAll.append(strPoker);
		else 
			isStand = true;			
	}

	public boolean isStand()
	{
		return isStand;
	}

	
	public void reset()
	{
		super.reset();
		isShowHand = false;
		isStand = false;
	}
	
	
}
