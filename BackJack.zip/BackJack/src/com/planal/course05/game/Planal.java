package com.planal.course05.game;

public class Planal extends Player
{
	public final static int NI_POKER_Y = 341;
	
	public Planal(Poker poker)
	{
		super(poker,NI_POKER_Y);
		isShowHand = true;
	}
	
	@Override
	public void drawTiles(String strPoker)
	{
		if(getPokerSum() < 5)
			sbufPokerAll.append(strPoker);
	}

}
