package com.planal.course05.game;

import android.graphics.Bitmap;
import android.graphics.Canvas;

import com.planal.course05.main.Main;
import com.planal.course05.tools.Tools;

public abstract class Player
{
	private final int NI_POKER_Y;
	public final Bitmap BMP_POKER_BACK = Tools.readImage(Main.getAssetManager(), "res/poker/back.png");
	
	protected Poker poker;
	protected StringBuffer sbufPokerAll;
	
	protected boolean isShowHand;
	private boolean isSoftHand;
	
	public Player(Poker poker,int niPokerY)
	{
		this.poker = poker;
		NI_POKER_Y = niPokerY;
		sbufPokerAll = new StringBuffer();
	}
	
	public String[] getPokerAll()
	{
		if(sbufPokerAll.length() > 0)
			return sbufPokerAll.toString().split(";");
		return null;		
	}
	
	public int getPokerSum()
	{
		String[] arrStrPokerAll = getPokerAll();
		if(arrStrPokerAll != null)
			return arrStrPokerAll.length;
		return 0;
	}
	
	public void onDraw(Canvas canvas)
	{
		//���û���˿��ƵĻ����ؿ�
		if(sbufPokerAll.length() == 0)
			return ;
		//�����Ϊ�վ�ִ������
		String[] arrStrPoker = getPokerAll();//��ü�����
		for (int i = 0; i < arrStrPoker.length; i++)
		{//��������������
			String[] arrStrPokerOne = arrStrPoker[i].split(",");
			//ÿ�����зֽ�����Ԫ��һ��Ϊ�ƵĻ�ɫ����һ��Ϊ�Ƶ���ֵ��
			byte nbType = Byte.parseByte(arrStrPokerOne[0]);
			byte nbDot = Byte.parseByte(arrStrPokerOne[1]);
			//�ƻ���X��λ�ã�����ץ�����ƶ��Ǿ�����ʾ����������Ҫ���ù��췽����poker
			final int NI_POKER_X = 
					Poker.NI_START_X + 
					(Poker.NI_RECT_MAX - poker.NI_WIDTH*arrStrPoker.length) / 2 
					+ i * poker.NI_WIDTH ;
			//�������ж���һ��boolean�����Ƿ���
			if(!isShowHand && i == 0)
				canvas.drawBitmap(BMP_POKER_BACK,NI_POKER_X,NI_POKER_Y,null);
			else
				canvas.drawBitmap(poker.getPoker(nbType, nbDot),NI_POKER_X,NI_POKER_Y,null);
		}
	}
	
	public byte getDot()
	{
		byte nbDotSum = 0;//��Ϸ�ߵ���
		byte nbANumber = 0;
		boolean isBeA = false;
		String[] arrStrPokertAll = getPokerAll();
		for (int i = 0; i < arrStrPokertAll.length; i++)
		{
			String[] arrCurPoker = arrStrPokertAll[i].split(",");
			byte nbDot = Byte.parseByte(arrCurPoker[1]);
			if(nbDot == 0)
			{
				nbANumber ++;
				isBeA = true;
			}
			else if(nbDot > 10)
			{
				nbDotSum += 10;
			}
			else
			{
				nbDotSum += (nbDot+1);
			}
		}
		if(isBeA)
		{
			for (int i = 0; i < nbANumber; i++)
			{
				if (nbDotSum+11 > 21) 
				{
					nbDotSum += 1;
				} 
				else
				{
					nbDotSum +=11;
					isSoftHand = true;
				}
			}
		}
		return nbDotSum;
	}
	
	public boolean isSoftHand()
	{
		isSoftHand = false;
		getDot();
		return isSoftHand;
	}
	
	public void showHand()
	{
		isShowHand = true;
	}
	
	public boolean isBeyondDot21()
	{
		return getDot() > 21;
	}
	
	public boolean isFiveDragon()
	{
		return getPokerSum() == 5 && getDot() <= 21;
	}
	
	public void reset()
	{
		sbufPokerAll.delete(0, sbufPokerAll.length());
	}
	
	public abstract void drawTiles(String strPoker);
	
}
