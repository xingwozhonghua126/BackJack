package com.planal.course05.ui;

import com.planal.course05.tools.Tools;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;

public class Button
{
	private int niX;
	private int niY;
	private int niState = 1;//0:���£�1�ɿ�
	
	private Bitmap[] arrBmp;
	private Rect rectBotton;
	
	public Button(Bitmap[] arrBmp,int niX,int niY)
	{
		this.arrBmp = arrBmp;
		this.niX = niX;
		this.niY = niY;
		
		rectBotton = new Rect(
				niX,
				niY,
				niX+arrBmp[niState].getWidth(),
				niY+arrBmp[niState].getHeight()
				);
	}
	
	public void onDraw(Canvas canvas)
	{
		canvas.drawBitmap(arrBmp[niState], niX, niY, null);
	}
	
	public boolean onTouchDown(float niTouchX,float niTouchY)
	{
		if(Tools.collideWith((int)niTouchX, (int)niTouchY, rectBotton))
		{
			niState = 0;
			return true;
		}
		return false;
	}
	
	public boolean onTouchUp(float niTouchX, float niTouchY)
	{
		if(niState == 0 && Tools.collideWith((int)niTouchX, (int)niTouchY, rectBotton))
		{
			niState = 1;
			return true;
		}
		return false;
	}

}
