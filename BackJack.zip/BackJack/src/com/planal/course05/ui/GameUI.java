package com.planal.course05.ui;

import com.planal.course05.game.PcGamer;
import com.planal.course05.game.Planal;
import com.planal.course05.game.Poker;
import com.planal.course05.main.Main;
import com.planal.course05.tools.Tools;

import android.graphics.Bitmap;
import android.graphics.Canvas;

public class GameUI
{
	private final int NI_BUST_ABSOLUTE_X;//����λ��
	private final int NI_BUST_ABSOLUTE_Y;
	
	public static final byte NB_STATE_PC_BUST = -1;//���Ա���
	public static final byte NB_STATE_PLANAL_BUST = -2;//��ұ���
	public static final byte NB_STATE_DOUBLE_BUST = -3;//������
	private byte nbBust;
	
	public static final byte NB_STATE_YOU_WIN = -4;
	public static final byte NB_STATE_YOU_LOST = -5;
	private byte nbWin$Lost;
	
	private Bitmap bmpBust;
	private Bitmap bmpYouLost;
	private Bitmap bmpYouWin;
	public GameUI(Poker poker)
	{
		bmpBust = Tools.readImage(Main.getAssetManager(), "res/ui/bust.png");
		bmpYouLost = Tools.readImage(Main.getAssetManager(), "res/ui/you_lose.png");
		bmpYouWin = Tools.readImage(Main.getAssetManager(), "res/ui/you_win.png");
		
		NI_BUST_ABSOLUTE_X = Poker.NI_START_X + (Poker.NI_RECT_MAX - bmpBust.getWidth())/2;
		NI_BUST_ABSOLUTE_Y = (poker.NI_HEIGHT - bmpBust.getHeight())/2;
	}
	
	public void onDraw(Canvas canvas)
	{
		switch(nbWin$Lost)
		{
		case NB_STATE_YOU_WIN:
			canvas.drawBitmap(bmpYouWin, (Main.getNiScreenWidth() - bmpYouWin.getWidth())/2,
					(Main.getNiScreenHeight() - bmpYouWin.getHeight())/2, null);
				break;
		case NB_STATE_YOU_LOST:
			canvas.drawBitmap(bmpYouLost, (Main.getNiScreenWidth() - bmpYouLost.getWidth())/2,
					(Main.getNiScreenHeight() - bmpYouLost.getHeight())/2, null);
				break;
		}
		
		switch(nbBust)
		{
		case NB_STATE_PC_BUST:
			canvas.drawBitmap(bmpBust, NI_BUST_ABSOLUTE_X,PcGamer.NI_POKER_Y + NI_BUST_ABSOLUTE_Y, null);
			break;
		case NB_STATE_PLANAL_BUST:
			canvas.drawBitmap(bmpBust, NI_BUST_ABSOLUTE_X,Planal.NI_POKER_Y + NI_BUST_ABSOLUTE_Y, null);
			break;
		case NB_STATE_DOUBLE_BUST:
			canvas.drawBitmap(bmpBust, NI_BUST_ABSOLUTE_X,Planal.NI_POKER_Y + NI_BUST_ABSOLUTE_Y, null);
			canvas.drawBitmap(bmpBust, NI_BUST_ABSOLUTE_X,PcGamer.NI_POKER_Y + NI_BUST_ABSOLUTE_Y, null);
			break;
		}
		

	}
	
	public void showBust(byte nbBustType)
	{
		nbBust = nbBustType;
	}
	
	public void showYouWin()
	{
		nbWin$Lost = NB_STATE_YOU_WIN;
	}
	
	public void showYouLost()
	{
		nbWin$Lost = NB_STATE_YOU_LOST;
	}
	
	public void reset()
	{
		nbWin$Lost = -128;
		nbBust = -128;
	}
}
