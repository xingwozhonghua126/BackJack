package com.planal.course05.ui;

import android.graphics.Bitmap;
import android.graphics.Canvas;

import com.planal.course05.main.Main;
import com.planal.course05.main.PlayerOperationListener;
import com.planal.course05.tools.Tools;

public class ButtonMonitor
{
	public static final int NI_BUTTON_Y = 288;
	
	private Button btnBecords ;
	private Button btnDelist ;
	private Button btnRestart;
	private Button btnQuit;
	
	private PlayerOperationListener pol;
	
	private boolean isVisible;
	private boolean isGameState = true;
	
	public ButtonMonitor(PlayerOperationListener pol)
	{
		this.pol = pol;	
		Bitmap[] arrBmpBecords = {
				Tools.readImage(Main.getAssetManager(), "res/ui/button/becards_down.png"),
				Tools.readImage(Main.getAssetManager(), "res/ui/button/becards_up.png")
		};
		btnBecords = new Button(arrBmpBecords,286,NI_BUTTON_Y);

		Bitmap[] arrBmpDelist = {
				Tools.readImage(Main.getAssetManager(), "res/ui/button/delist_down.png"),
				Tools.readImage(Main.getAssetManager(), "res/ui/button/delist_up.png")
		};
		btnDelist = new Button(arrBmpDelist,449,NI_BUTTON_Y);

		Bitmap[] arrBmpRestart = {
				Tools.readImage(Main.getAssetManager(), "res/ui/button/restart_down.png"),
				Tools.readImage(Main.getAssetManager(), "res/ui/button/restart_up.png")
		};
		btnRestart = new Button(arrBmpRestart,278,NI_BUTTON_Y);

		Bitmap[] arrBmpQuit = {
				Tools.readImage(Main.getAssetManager(), "res/ui/button/quit_down.png"),
				Tools.readImage(Main.getAssetManager(), "res/ui/button/quit_up.png")
		};
		btnQuit = new Button(arrBmpQuit,413,NI_BUTTON_Y);

	}
	
	public void onDraw(Canvas canvas)
	{
		if(isVisible == false)
			return;
		if(isGameState)
		{
			btnBecords.onDraw(canvas);
			btnDelist.onDraw(canvas);
		}
		else
		{
			btnRestart.onDraw(canvas);
			btnQuit.onDraw(canvas);
		}

	}
	
	public void onTouchDown(float nfTouchX, float nfTouchY)
	{
		if(isVisible == false)
			return;
		
		if(isGameState)
		{	//Ҫ�ƺ�ͣ������Ϸ������
			btnBecords.onTouchDown(nfTouchX, nfTouchY);
			btnDelist.onTouchDown(nfTouchX, nfTouchY);		
		}
		else
		{	//���¿�ʼ���˳���Ϸ
			btnRestart.onTouchDown(nfTouchX, nfTouchY);
			btnQuit.onTouchDown(nfTouchX, nfTouchY);
		}

	}
	
	public void onTouchUp(float nfTouchX, float nfTouchY)
	{
		if(isVisible == false)
			return;
		if(isGameState)
		{
			if(btnBecords.onTouchUp(nfTouchX, nfTouchY))
			{
				pol.notifyPlayerBecards();
				isVisible = false;
			}
			if(btnDelist.onTouchUp(nfTouchX, nfTouchY))
			{
				pol.notifyPlayerDelist();
				isVisible = false;
			}
		}
		else
		{
			if(btnRestart.onTouchUp(nfTouchX, nfTouchY))
			{
				pol.notifyRestart();
			}
			if(btnQuit.onTouchUp(nfTouchX, nfTouchY))
			{
				pol.notifyQuit();
			}
		}
	}
	
	public void setVisible(boolean is)
	{
		isVisible = is;
	}
	
	public void setGameState(boolean is)
	{
		isGameState = is;
	}
	
	public void reset()
	{
		isGameState = true;
		isVisible = false;
	}

}