package com.planal.course05.main;

public interface ExitAppListener
{
	void finish();
}
