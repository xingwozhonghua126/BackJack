package com.planal.course05.main;

import com.planal.couse05.main.R;

import android.app.Activity;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.MotionEvent;

public class Main extends Activity
{
	private MainMonitor mainMonitor;
	private static AssetManager am;
	private static int niScreenWidth,niScreenHeight;
	
	public static final int getNiScreenWidth(){return niScreenWidth;}

	public static final int getNiScreenHeight(){return niScreenHeight;}

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		Display display = getWindowManager().getDefaultDisplay();
		niScreenWidth = display.getWidth();
		niScreenHeight = display.getHeight();
		am = getAssets();
		mainMonitor = new MainMonitor(this,new ExitAppMonitor());
		setContentView(mainMonitor);

	}

	public static final AssetManager getAssetManager(){return am;}

	@Override
	public boolean onTouchEvent(MotionEvent event)
	{
		switch (event.getAction()) 
		{
		case    MotionEvent.ACTION_DOWN:
			mainMonitor.OnTouchDown(event.getX(), event.getY());
			break;
		case    MotionEvent.ACTION_UP:
			mainMonitor.OnTouchUp(event.getX(), event.getY());
			break;
		}
		return super.onTouchEvent(event);
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	private class ExitAppMonitor implements ExitAppListener
	{

		@Override
		public void finish()
		{
			Main.super.finish();
			System.exit(0);
		}

	}
}
