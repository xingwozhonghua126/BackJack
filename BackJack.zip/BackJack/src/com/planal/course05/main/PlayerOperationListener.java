package com.planal.course05.main;

public interface PlayerOperationListener
{
	void notifyPlayerBecards();
	
	void notifyPlayerDelist();

	void notifyRestart();

	void notifyQuit();
}
