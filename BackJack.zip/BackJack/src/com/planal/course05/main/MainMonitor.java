package com.planal.course05.main;

import com.planal.course05.game.PcGamer;
import com.planal.course05.game.Planal;
import com.planal.course05.game.Poker;
import com.planal.course05.tools.Tools;
import com.planal.course05.ui.Button;
import com.planal.course05.ui.ButtonMonitor;
import com.planal.course05.ui.GameUI;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.view.View;

public class MainMonitor extends View
{
	private Bitmap bmpBackground;
	private Poker poker;
	private Planal planal;
	private PcGamer pcGamer;
	private ButtonMonitor btnMonitor;
	private GameUI gameUI;
	private ExitAppListener eal;

	
	public MainMonitor(Context context,ExitAppListener eal)
	{
		super(context);
		this.eal = eal;
		// TODO Auto-generated constructor stub
		bmpBackground = Tools.readImage(Main.getAssetManager(), "res/ui/background.png");
		poker = new Poker();
		planal = new Planal(poker);
		pcGamer = new PcGamer(poker);
		btnMonitor = new ButtonMonitor(new PlayerOperationMonitor());
		gameUI = new GameUI(poker);
		
		startGame();

	}

	private void reset()
	{
		poker.shuffle();
		planal.reset();
		pcGamer.reset();
		gameUI.reset();
		btnMonitor.reset();
		postInvalidate();
	}
	
	
	protected void onDraw(Canvas canvas)
	{
		canvas.drawBitmap(bmpBackground, 0,0, null);
		planal.onDraw(canvas);
		pcGamer.onDraw(canvas);
		btnMonitor.onDraw(canvas);
		gameUI.onDraw(canvas);
	}

	public void OnTouchDown(float nfTouchX,float nfTouchY)
	{
		btnMonitor.onTouchDown(nfTouchX, nfTouchY);
		postInvalidate();
	}

	public void OnTouchUp(float nfTouchX,float nfTouchY)
	{
		btnMonitor.onTouchUp(nfTouchX, nfTouchY);
		postInvalidate();
	}
	
	private void startGame()
	{
		new Thread(new StartGame()).start();
	}
	
	private class StartGame implements Runnable
	{
		public void run()
		{
			for (int i = 0; i < 4; i++)
			{
				try
				{Thread.sleep(50);} catch (InterruptedException e){}
				if(i % 2 == 0)
					planal.drawTiles(poker.dealing());
				else
					pcGamer.drawTiles(poker.dealing());
				postInvalidate();
			}
			btnMonitor.setVisible(true);
			postInvalidate();
		}
	}
	
	private class PlayerOperationMonitor implements PlayerOperationListener
	{
		public void notifyPlayerBecards()
		{
			new Thread(new PlayerBecardsLogic()).start();

		}
		
		public void notifyPlayerDelist()
		{
			new Thread(new PlayerDelistLogic()).start();
		}
		
		@Override
		public void notifyRestart()
		{
			reset();
			startGame();
		}

		@Override
		public void notifyQuit()
		{
			eal.finish();
		}
		
		private class PlayerDelistLogic implements Runnable
		{
			public void run()
			{
				btnMonitor.setVisible(false);
				postInvalidate();
				while(pcGamer.isStand() == false)
				{
					try{Thread.sleep(500);} catch (InterruptedException e){}//ͣ�ٰ���
					pcGamer.drawTiles(poker.dealing());
					if(pcGamer.isBeyondDot21())
					{
						pcGamer.showHand();
						gameUI.showBust(GameUI.NB_STATE_PC_BUST);
						gameUI.showYouWin();
						btnMonitor.setGameState(false);
						btnMonitor.setVisible(true);
						postInvalidate();
						return ;
					}
				}
				if((pcGamer.isFiveDragon() && planal.isFiveDragon())||
						(!pcGamer.isFiveDragon() && !planal.isFiveDragon()))
				{
					if(planal.getDot() > pcGamer.getDot())
						gameUI.showYouWin();
					else
						gameUI.showYouLost();
				}
				else
				{
					if(planal.isFiveDragon())
						gameUI.showYouWin();
					else
						gameUI.showYouLost();
				}
				pcGamer.showHand();
				btnMonitor.setGameState(false);
				btnMonitor.setVisible(true);
				postInvalidate();
			}
			
		}
		
		private class PlayerBecardsLogic implements Runnable
		{
			@Override
			public void run()
			{
				btnMonitor.setVisible(false);//���ذ�ť
				postInvalidate();//�ػ�
				planal.drawTiles(poker.dealing());//���ץ��
				try{Thread.sleep(500);} catch (InterruptedException e){}//ͣ�ٰ���
				
				pcGamer.drawTiles(poker.dealing());//����ץ��
				if(planal.isBeyondDot21() && pcGamer.isBeyondDot21())
				{
					pcGamer.showHand();
					gameUI.showBust(GameUI.NB_STATE_DOUBLE_BUST);
					btnMonitor.setGameState(false);
				}
				else if(planal.isBeyondDot21())
				{
					pcGamer.showHand();
					gameUI.showBust(GameUI.NB_STATE_PLANAL_BUST);
					gameUI.showYouLost();
					btnMonitor.setGameState(false);
				}
				else if(pcGamer.isBeyondDot21())
				{
					pcGamer.showHand();
					gameUI.showBust(GameUI.NB_STATE_PC_BUST);
					gameUI.showYouWin();
					btnMonitor.setGameState(false);
				}
				else if(planal.getPokerSum() == 5)
				{
					notifyPlayerDelist();
				}
				btnMonitor.setVisible(true);//��ʾ��ť
				postInvalidate();
			}
			
		}

	}
}
